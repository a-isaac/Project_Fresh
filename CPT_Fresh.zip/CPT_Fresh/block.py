#-------------------------------------------------------------------------------
# Name:        module4
# Purpose:
#
# Author:      User
#
# Created:     20/01/2013
# Copyright:   (c) User 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python
import pygame
import random
import math
import os
os.environ['SDL_VIDEODRIVER']='windib'
#set colours
black    = (   0,   0,   0)
white    = ( 255, 255, 255)
red      = ( 255,   0,   0)
blue     = ( 0,   0,   255)
green     = ( 51,   255,   51)
blueFresh     = (   1, 157, 255)
bluStew = (19,82,149)
orange = (155,131,106)
rBlue = (17,40,110)
#
"""This class represents the block"""
class Block(pygame.sprite.Sprite):

    """Constructor. Pass in the color of the block,
    # and its x and y position"""
    def __init__(self, filename):
        # Call the parent class (Sprite) constructor
        pygame.sprite.Sprite.__init__(self)

        # Create an image of the block, and fill it with a color.
        # This could also be an image loaded from the disk.
        #self.image = pygame.Surface([width, height])
        #self.image.fill(color)
        self.image = pygame.image.load(filename).convert()
        self.image.set_colorkey(black)

        # Fetch the rectangle object that has the dimensions of the image
        # image.
        # Update the position of this object by setting the values
        # of rect.x and rect.y
        self.rect = self.image.get_rect()
